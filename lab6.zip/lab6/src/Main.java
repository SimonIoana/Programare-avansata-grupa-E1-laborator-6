import forme.main_frame;

public class Main {

    public static void main(String[] args) {
        new main_frame().setVisible(true);
    }
}