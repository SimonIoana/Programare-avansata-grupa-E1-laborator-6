/**
 * 
 */
/**
 * @author Ioana
 *
 */
module lab6_comp {
}